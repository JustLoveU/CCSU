window.eruptSiteConfig = {
    domain: "https://ou.lomtom.top",
    fileDomain: "",
    title: "易留学",
    desc: "让你的留学变得简单",
    dialogLogin: false,
    copyright: false, //是否保留显示版权信息
    logoPath: "/assets/logo.png",
    logoText: "易留学",
    registerPage: null,
    amapKey: null
};
